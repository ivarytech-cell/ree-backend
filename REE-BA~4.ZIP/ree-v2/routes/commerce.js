// routes/commerce.js — Mi Comercio + White-label branding
// GET  /api/config        — PUBLIC (no auth): returns branding keys (app_name, logo, etc.)
// GET  /api/commerce      — authenticated: full key-value store
// PUT  /api/commerce      — authenticated: update any allowed key
const express = require('express')
const router = express.Router()
const { getDb } = require('../database')
const authMiddleware = require('../middleware/auth')

// Keys allowed in commerce_info
const ALLOWED_KEYS = [
  // Business info
  'business_name', 'address', 'city', 'country', 'phone', 'email', 'website',
  'facebook', 'instagram', 'whatsapp',
  'currency_primary', 'currency_secondary',
  'rfc', 'rnc', 'business_hours', 'logo_url', 'description',
  // Branding / white-label
  'app_name', 'app_logo', 'app_favicon',
  'ai_agent_name', 'ai_agent_description',
]

// Keys exposed publicly (no auth needed)
const PUBLIC_KEYS = ['app_name', 'app_logo', 'app_favicon', 'ai_agent_name', 'ai_agent_description', 'business_name', 'currency_primary']

function rowsToObj(rows) {
  return rows.reduce((acc, r) => { acc[r.key] = r.value; return acc }, {})
}

// ─── PUBLIC: branding config (no auth) ───────────────────────────────────────
router.get('/config', (req, res) => {
  try {
    const db = getDb()
    const rows = db.prepare(
      `SELECT key, value FROM commerce_info WHERE key IN (${PUBLIC_KEYS.map(() => '?').join(',')})`
    ).all(...PUBLIC_KEYS)
    res.json(rowsToObj(rows))
  } catch (err) {
    console.error('GET /config error:', err)
    res.json({}) // always return JSON even on error so frontend doesn't crash
  }
})

// ─── AUTHENTICATED routes below ──────────────────────────────────────────────
router.use(authMiddleware)

// GET /api/commerce — full commerce info
router.get('/', (req, res) => {
  try {
    const db = getDb()
    const rows = db.prepare('SELECT key, value FROM commerce_info').all()
    res.json(rowsToObj(rows))
  } catch (err) {
    console.error('GET /commerce error:', err)
    res.status(500).json({ error: 'Error al obtener información comercial' })
  }
})

// PUT /api/commerce — upsert one or many keys
router.put('/', (req, res) => {
  try {
    const db = getDb()
    const updates = req.body
    const stmt = db.prepare(
      `INSERT INTO commerce_info (key, value, updated_at)
       VALUES (?, ?, datetime('now'))
       ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at`
    )

    const upserted = {}
    for (const [key, value] of Object.entries(updates)) {
      if (!ALLOWED_KEYS.includes(key)) continue // silently skip unknown keys
      stmt.run(key, String(value ?? ''))
      upserted[key] = value
    }

    // Return updated full object
    const rows = db.prepare('SELECT key, value FROM commerce_info').all()
    res.json(rowsToObj(rows))
  } catch (err) {
    console.error('PUT /commerce error:', err)
    res.status(500).json({ error: 'Error al guardar información comercial' })
  }
})

module.exports = router
