// routes/stats.js
const express = require('express');
const { getDb } = require('../db/database');
const { authMiddleware } = require('../middleware/auth');
const router = express.Router();

function dateFilter(from, to) {
  if (from && to) return { clause: 'AND created_at BETWEEN ? AND ?', params: [from, to] };
  if (from) return { clause: 'AND created_at >= ?', params: [from] };
  const d = new Date(); d.setDate(d.getDate() - 30);
  return { clause: 'AND created_at >= ?', params: [d.toISOString().split('T')[0]] };
}

// ── Overview ──────────────────────────────────────────────────────────────────
router.get('/overview', authMiddleware, (req, res) => {
  const db = getDb();
  const { from, to } = req.query;
  const { clause, params } = dateFilter(from, to);

  const totalConv = db.prepare(`SELECT COUNT(*) as n FROM conversations WHERE 1=1 ${clause}`).get(...params)?.n || 0;
  const totalOrders = db.prepare(`SELECT COUNT(*) as n FROM orders WHERE 1=1 ${clause}`).get(...params)?.n || 0;
  const revenue = db.prepare(`SELECT COALESCE(SUM(total),0) as t FROM orders WHERE status!='cancelled' ${clause}`).get(...params)?.t || 0;
  const clients = db.prepare(`SELECT COUNT(*) as n FROM clients WHERE 1=1 ${clause}`).get(...params)?.n || 0;
  const aiManaged = db.prepare(`SELECT COUNT(*) as n FROM conversations WHERE is_ai_managed=1 ${clause}`).get(...params)?.n || 0;
  const needsHuman = db.prepare(`SELECT COUNT(*) as n FROM conversations WHERE needs_human=1 ${clause}`).get(...params)?.n || 0;
  const purchaseIntent = db.prepare(`SELECT COUNT(*) as n FROM conversations WHERE has_purchase_intent=1 ${clause}`).get(...params)?.n || 0;

  res.json({
    conversations: { total: totalConv, ai_managed: aiManaged, needs_human: needsHuman, purchase_intent: purchaseIntent },
    orders: { total: totalOrders, revenue },
    clients: { total: clients },
    ai_resolution_rate: totalConv > 0 ? Math.round((aiManaged / totalConv) * 100) : 0
  });
});

// ── Message volume ─────────────────────────────────────────────────────────────
router.get('/messages', authMiddleware, (req, res) => {
  const db = getDb();
  const { from, to } = req.query;
  const { clause, params } = dateFilter(from, to);

  const byChannel = db.prepare(`
    SELECT channel, COUNT(*) as count FROM conversations WHERE 1=1 ${clause} GROUP BY channel
  `).all(...params);

  const byDay = db.prepare(`
    SELECT DATE(created_at) as day, COUNT(*) as count
    FROM conversations WHERE 1=1 ${clause}
    GROUP BY day ORDER BY day
  `).all(...params);

  const msgTotal = db.prepare(`SELECT COUNT(*) as n FROM messages WHERE 1=1 ${clause.replace(/created_at/g, 'sent_at')}`).get(...params)?.n || 0;

  res.json({ by_channel: byChannel, by_day: byDay, total_messages: msgTotal });
});

// ── Agent performance ─────────────────────────────────────────────────────────
router.get('/agents', authMiddleware, (req, res) => {
  const db = getDb();
  const { from, to } = req.query;
  const { clause, params } = dateFilter(from, to);

  const agentStats = db.prepare(`
    SELECT a.id, a.name, a.last_name, a.status, a.role,
      COUNT(c.id) as total_conversations,
      SUM(CASE WHEN c.status='open' THEN 1 ELSE 0 END) as open_conversations,
      SUM(CASE WHEN c.status='resolved' THEN 1 ELSE 0 END) as resolved_conversations
    FROM agents a
    LEFT JOIN conversations c ON a.id = c.assigned_agent_id AND c.created_at >= ?
    GROUP BY a.id ORDER BY total_conversations DESC
  `).all(params[0]);

  const msgByAgent = db.prepare(`
    SELECT m.sender_name, COUNT(*) as msg_count
    FROM messages m WHERE m.sender_type='agent' ${clause.replace(/created_at/g, 'sent_at')}
    GROUP BY m.sender_name ORDER BY msg_count DESC
  `).all(...params);

  res.json({ agent_stats: agentStats, messages_by_agent: msgByAgent });
});

// ── Sales stats ───────────────────────────────────────────────────────────────
router.get('/sales', authMiddleware, (req, res) => {
  const db = getDb();
  const { from, to } = req.query;
  const { clause, params } = dateFilter(from, to);

  const byStatus = db.prepare(`
    SELECT status, COUNT(*) as count, COALESCE(SUM(total),0) as revenue
    FROM orders WHERE 1=1 ${clause} GROUP BY status
  `).all(...params);

  const byChannel = db.prepare(`
    SELECT channel_name, COUNT(*) as count, COALESCE(SUM(total),0) as revenue
    FROM orders WHERE 1=1 ${clause} GROUP BY channel_name ORDER BY revenue DESC
  `).all(...params);

  const topProducts = db.prepare(`
    SELECT oi.product_name, SUM(oi.quantity) as units, SUM(oi.subtotal) as revenue
    FROM order_items oi
    JOIN orders o ON oi.order_id = o.id
    WHERE o.status != 'cancelled' ${clause.replace(/created_at/g, 'o.created_at')}
    GROUP BY oi.product_name ORDER BY units DESC LIMIT 10
  `).all(...params);

  const byDay = db.prepare(`
    SELECT DATE(created_at) as day, COUNT(*) as orders, COALESCE(SUM(total),0) as revenue
    FROM orders WHERE status!='cancelled' ${clause} GROUP BY day ORDER BY day
  `).all(...params);

  res.json({ by_status: byStatus, by_channel: byChannel, top_products: topProducts, by_day: byDay });
});

// ── AI agent stats ─────────────────────────────────────────────────────────────
router.get('/ai', authMiddleware, (req, res) => {
  const db = getDb();
  const { from, to } = req.query;
  const { clause, params } = dateFilter(from, to);

  const total = db.prepare(`SELECT COUNT(*) as n FROM conversations WHERE 1=1 ${clause}`).get(...params)?.n || 0;
  const ai_handled = db.prepare(`SELECT COUNT(*) as n FROM conversations WHERE is_ai_managed=1 ${clause}`).get(...params)?.n || 0;
  const escalated = db.prepare(`SELECT COUNT(*) as n FROM conversations WHERE needs_human=1 ${clause}`).get(...params)?.n || 0;
  const intent = db.prepare(`SELECT COUNT(*) as n FROM conversations WHERE has_purchase_intent=1 ${clause}`).get(...params)?.n || 0;
  const orders_from_intent = db.prepare(`SELECT COUNT(*) as n FROM orders WHERE 1=1 ${clause}`).get(...params)?.n || 0;

  const by_day = db.prepare(`
    SELECT DATE(created_at) as day,
      SUM(is_ai_managed) as ai_handled,
      COUNT(*) as total
    FROM conversations WHERE 1=1 ${clause}
    GROUP BY day ORDER BY day
  `).all(...params);

  res.json({
    total_conversations: total,
    ai_handled,
    escalation_rate: total > 0 ? Math.round((escalated / total) * 100) : 0,
    resolution_rate: total > 0 ? Math.round(((ai_handled - escalated) / Math.max(ai_handled, 1)) * 100) : 0,
    purchase_intent: intent,
    intent_to_order_rate: intent > 0 ? Math.round((orders_from_intent / intent) * 100) : 0,
    by_day
  });
});

// ── Campaigns stats ───────────────────────────────────────────────────────────
router.get('/campaigns', authMiddleware, (req, res) => {
  const db = getDb();
  const campaigns = db.prepare('SELECT * FROM campaigns ORDER BY created_at DESC').all();
  res.json({ campaigns });
});

module.exports = router;
